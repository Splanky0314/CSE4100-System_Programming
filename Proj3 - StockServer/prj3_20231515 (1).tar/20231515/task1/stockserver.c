/* 
 * echoserveri.c - An iterative echo server 
 */ 
/* $begin echoserverimain */
#include "csapp.h"

/* data manage를 위한 BINARY TREE */
typedef struct item {
    int ID;
    int left_stock;
    int price;
    // int readcnt;
    // sem_t mutex; // 여러 thread or process가 동일한 주식 데이터 노드에 접근하는 경우 제어를 위해

    struct item *left;
    struct item *right;
} item;

item *root = NULL;

item* create_node(int ID, int left_stock, int price) {
    item* node = (item*)malloc(sizeof(item));
    node->ID = ID;
    node->left_stock = left_stock;
    node->price = price;

    node->left = node->right = NULL;
    return node;
}

// MST 구조로 item을 insert
item* insert_node(item *root, item *new_node) {
    if (root == NULL) return new_node;
    if (new_node->ID < root->ID)
        root->left = insert_node(root->left, new_node);
    else
        root->right = insert_node(root->right, new_node);
    return root;
}

// stock.txt 읽어서 주식정보를 Binary Tree 형태로 저장해야
void read_stocktxt() {
    FILE *fp = fopen("stock.txt", "r");

    char buf[MAXLINE];
    while (fgets(buf, MAXLINE, fp) != NULL) {
        int id, stock, price;
        sscanf(buf, "%d %d %d", &id, &stock, &price);
        item *new_item = create_node(id, stock, price);
        root = insert_node(root, new_item);
    }

    fclose(fp);
}

void write_stocktxt_inorder(FILE *fp, item *root) {
    if (root == NULL) return;

    write_stocktxt_inorder(fp, root->left);
    fprintf(fp, "%d %d %d\n", root->ID, root->left_stock, root->price);
    write_stocktxt_inorder(fp, root->right);
}

void write_stocktxt() { 
    FILE *fp = fopen("stock.txt", "w");
    // MST를 중위순회하며 노드 내용 출력(ID 기준 오름차순으로 정렬됨)
    write_stocktxt_inorder(fp, root);

    fclose(fp);
}

// pool 구현
typedef struct {
    int maxfd;
	fd_set read_set;
	fd_set ready_set;
	int nready;
	int maxi;
	int clientfd[FD_SETSIZE];
	rio_t clientrio[FD_SETSIZE];
} pool;

void init_pool(int listenfd, pool *p){
	p->maxi = -1;
	for(int i=0; i<FD_SETSIZE; i++) {
        p->clientfd[i] = -1; // 모두 -1로 초기화
    }
    p->maxfd = listenfd; 
	FD_ZERO(&p->read_set); // bit vec 모두 0으로 초기화
	FD_SET(listenfd, &p->read_set); // listenfd만 활성화
}

void add_client(int connfd, pool *p){
	int i;
	p->nready--; // pending input이 있는 fd 하나를 처리했기에
	for(i=0; i<FD_SETSIZE; i++){ // fd 순회
		if(p->clientfd[i] < 0){ // 빈 배열 원소라면
			p->clientfd[i] = connfd; // connfd 저장
			Rio_readinitb(&p->clientrio[i], connfd);
			
			FD_SET(connfd, &p->read_set); // connfd를 활성화 상태로 
			
			if(connfd > p->maxfd) p->maxfd = connfd;
			if(i> p->maxi) p->maxi = i;
			
			break;
		}
	}
	if(i == FD_SETSIZE) app_error("add_client error : too many clients");
}

// show 명령어의 반환값을 저장하기 위한 변수
char response[MAXLINE];

void show_stocks(int connfd, item* node) {
    if(node == NULL) return;
    char output[MAXLINE] = {};
    int len = sprintf(output, "%d %d %d\n", node->ID, node->left_stock, node->price);
    // printf("%d %d %d\n", node->ID, node->left_stock, node->price); // for test
    // Rio_writen(connfd, output, len);
    
    // MST를 inorder(중위순회)하여 결과 출력 -> ID 기준으로 오름차순 정렬
    show_stocks(connfd, node->left);
    strcat(response, output);
    show_stocks(connfd, node->right);
}

// 주어진 ID와 일치하는 item을 반환
item* return_stock_item_by_ID(item* node, int ID) {
    while(node != NULL) {
        if(node->ID == ID) return node;
        else if(node->ID < ID) {
            node = node->right;
        }
        else if(node->ID > ID) {
            node = node->left;
        }
    }

    return NULL;
}

// success -> return 1, else -> return 0;
int buy_stock(int ID, int amount) {
    item* target = return_stock_item_by_ID(root, ID);
    if(target == NULL) return 0;
    if(target->left_stock >= amount) { // 재고가 충분하다면,
        target->left_stock -= amount;
        return 1;
    }
    else {
        // err, 재고 부족
        return 0;
    }
}

int sell_stock(int ID, int amount) {
    item* target = return_stock_item_by_ID(root, ID);
    if(target == NULL) return 0;
    target->left_stock += amount;
    return 1;
}

// 서버 종료 시, stock.txt에 내용 저장
void sigint_handler(int sig) {
    write_stocktxt();  // 서버 종료 전에 stock 저장
    exit(0);
}

void check_client(pool *p){
	int n, connfd;
	char buf[MAXLINE];
	rio_t rio;

    // nready가 아직 남은 경우, connfd 배열 순회
	for(int i=0; (i <= p->maxi) && (p->nready > 0); i++){
		connfd = p->clientfd[i];
		rio = p->clientrio[i];

        // 현재 connfd에 pending input이 존재하는 경우,
		if((connfd > 0) && (FD_ISSET(connfd, &p->ready_set))){
			p->nready--;
			if((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0){
				printf("Server received %d bytes on fd %d\n", n, connfd); //// 체크 필요
				
                // printf("INPUTVAL: %s\n", buf); // for test
				if(!strncmp(buf, "show", 4)) {
                    response[0] = '\0'; // 초기화
					show_stocks(connfd, root);
                    Rio_writen(connfd, response, MAXLINE);
				}
				
				else if(!strncmp(buf, "buy", 3)) {
                    char trashstr[MAXLINE];
					int inputid, inputamount;
                    sscanf(buf, "%s %d %d", trashstr, &inputid, &inputamount);
                    if(buy_stock(inputid, inputamount)) {
                        Rio_writen(connfd, "[buy] success\n", MAXLINE); // 체크 필요
                    }
                    else { // txt에 없는 stock이거나, 수량 부족하거나
                        Rio_writen(connfd, "Not enough left stock\n", MAXLINE); // 체크 필요
                    }

				}
				else if(!strncmp(buf, "sell", 4)) {
					char trashstr[MAXLINE];
					int inputid, inputamount;
                    sscanf(buf, "%s %d %d", trashstr, &inputid, &inputamount);
                    if(sell_stock(inputid, inputamount)) {
                        Rio_writen(connfd, "[sell] success\n", MAXLINE); // 체크 필요
                    }
                    else { // 해당 ID의 stock이 없는 경우, -> 출력 없이 건너뛰기
                        Rio_writen(connfd, "\n", MAXLINE);
                    }
				}
                else if(!strncmp(buf, "exit", 4)) {
                    // write_stocktxt(); // 한 thread 종료될 때 txt 저장 // 없어도 되긴 함.
                    Rio_writen(connfd, "exit\n", MAXLINE);
                    Close(connfd);
                    FD_CLR(connfd, &p->read_set); 
                    p->clientfd[i] = -1; // connfd 배열에서 제거
                    return;
				}
			}
			else { // EOF
				Close(connfd);
				FD_CLR(connfd, &p->read_set); 
				p->clientfd[i] = -1; // connfd 배열에서 제거
			}
		}
	}
}

void echo(int connfd);

int main(int argc, char **argv) 
{
    Signal(SIGINT, sigint_handler); 

    int listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;   /* Enough space for any address */  //line:netp:echoserveri:sockaddrstorage
    char client_hostname[MAXLINE], client_port[MAXLINE]; //
    static pool pool;

    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }

    // stock.txt 내용 읽기
    read_stocktxt();

    listenfd = Open_listenfd(argv[1]); // listen까지의 작업 수행
    init_pool(listenfd, &pool);

    while(1) {
        // listening, connected descriptor들이 준비될 때까지 기다림
        pool.ready_set = pool.read_set;
        pool.nready = Select(pool.maxfd + 1, &pool.ready_set, NULL, NULL, NULL);

        // listening descriptor가 준비되었다면, 
        // new client를 pool에 추가
        if(FD_ISSET(listenfd, &pool.ready_set)) {
            clientlen = sizeof(struct sockaddr_storage); 
	        connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
            Getnameinfo((SA *) &clientaddr, clientlen, client_hostname, MAXLINE, client_port, MAXLINE, 0);
            printf("Connected to (%s, %s)\n", client_hostname, client_port);

            add_client(connfd, &pool);
        }

        check_client(&pool); // 체크 필요 connfd 안넘겨도 되나?
        // echo(connfd);
    }
    exit(0);
}
/* $end echoserverimain */
