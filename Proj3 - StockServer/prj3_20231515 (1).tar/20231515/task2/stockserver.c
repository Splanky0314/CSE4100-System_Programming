/* 
 * echoserveri.c - An iterative echo server 
 */ 
/* $begin echoserverimain */
#include "csapp.h"
#define NTHREADS 100
#define SBUFSIZE 32

/* data manage를 위한 BINARY TREE */
typedef struct item {
    int ID;
    int left_stock;
    int price;
    int readcnt;
    sem_t mutex, w; // 여러 thread or process가 동일한 주식 데이터 노드에 접근하는 경우 제어를 위해

    struct item *left;
    struct item *right;
} item;

item *root = NULL;

item* create_node(int ID, int left_stock, int price) {
    item* node = (item*)malloc(sizeof(item));
    node->ID = ID;
    node->left_stock = left_stock;
    node->price = price;
    node->readcnt = 0;
    Sem_init(&node->mutex, 0, 1);
    Sem_init(&node->w, 0, 1);
    node->left = node->right = NULL;
    return node;
}

// MST 구조로 item을 insert
item* insert_node(item *root, item *new_node) {
    if (root == NULL) return new_node;
    if (new_node->ID < root->ID)
        root->left = insert_node(root->left, new_node);
    else
        root->right = insert_node(root->right, new_node);
    return root;
}

// stock.txt 읽어서 주식정보를 Binary Tree 형태로 저장해야
void read_stocktxt() {
    FILE *fp = fopen("stock.txt", "r");

    char buf[MAXLINE];
    while (fgets(buf, MAXLINE, fp) != NULL) {
        int id, stock, price;
        sscanf(buf, "%d %d %d", &id, &stock, &price);
        item *new_item = create_node(id, stock, price);
        root = insert_node(root, new_item);
    }

    fclose(fp);
}

void write_stocktxt_inorder(FILE *fp, item *root) {
    if (root == NULL) return;

    write_stocktxt_inorder(fp, root->left);
    fprintf(fp, "%d %d %d\n", root->ID, root->left_stock, root->price);
    write_stocktxt_inorder(fp, root->right);
}

void write_stocktxt() { 
    FILE *fp = fopen("stock.txt", "w");
    // MST를 중위순회하며 노드 내용 출력(ID 기준 오름차순으로 정렬됨)
    write_stocktxt_inorder(fp, root);

    fclose(fp);
}


void echo(int connfd);

/* Thread-Based Concurrent Server */

/* sbuf 관련 */
typedef struct sbuf_t {
    int* buf; // buffer array
    int n; // slot의 최대 개수
    int front;  // 첫 번째 item
    int rear;  // 마지막 item
    sem_t mutex; 
    sem_t slots; 
    sem_t items; 
} sbuf_t;

sbuf_t sbuf; 

int read_cnt, byte_cnt;
sem_t mutex, w;

void sbuf_init(struct sbuf_t *sp, int n) {
  sp->buf = Calloc(n, sizeof(int));
  sp->n = n;
  sp->front = sp->rear = 0;
  Sem_init(&sp->mutex, 0, 1);
  Sem_init(&sp->slots, 0, n);
  Sem_init(&sp->items, 0, 0);
}

void sbuf_deinit(sbuf_t* sp)
{
    Free(sp->buf);
}

void sbuf_insert(struct sbuf_t *sp, int connfd) {
  P(&sp->slots);
  P(&sp->mutex);
  sp->buf[(++sp->rear) % (sp->n)] = connfd;
  V(&sp->mutex);
  V(&sp->items);
}

int sbuf_remove(struct sbuf_t *sp) {
  int connfd;
  P(&sp->items);
  P(&sp->mutex);
  connfd = sp->buf[(++sp->front) % (sp->n)];
  V(&sp->mutex);
  V(&sp->slots);
  return connfd;
}


void *thread(void *vargp) {
  struct sbuf_t *sbufp = vargp;
  rio_t rio;

  Pthread_detach(pthread_self());

  while (1) {
    int connfd = sbuf_remove(sbufp);
    Rio_readinitb(&rio, connfd);
    check_client(connfd);
    Close(connfd);
  }
}

/* stock 관리 명령 처리 */

char response[MAXLINE];

void show_stocks(int connfd, item* node) {
    if(node == NULL) return;
    char output[MAXLINE] = {};

    // MST를 inorder(중위순회)하여 결과 출력 -> ID 기준으로 오름차순 정렬
    show_stocks(connfd, node->left);

    // Reader lock 시작
    P(&node->mutex);
    node->readcnt++;
    if (node->readcnt == 1)
        P(&node->w);  // 첫 reader가 writer 접근 차단
    V(&node->mutex);

    int len = sprintf(output, "%d %d %d\n", node->ID, node->left_stock, node->price);
    // printf("%d %d %d\n", node->ID, node->left_stock, node->price); // for test
    // Rio_writen(connfd, output, len);

    // Reader lock 해제
    P(&node->mutex);
    node->readcnt--;
    if (node->readcnt == 0)
        V(&node->w);  // 마지막 reader가 writer 허용
    V(&node->mutex);

    strcat(response, output);
    show_stocks(connfd, node->right);
}

// 주어진 ID와 일치하는 item을 반환
item* return_stock_item_by_ID(item* node, int ID) {
    while(node != NULL) {
        if(node->ID == ID) return node;
        else if(node->ID < ID) {
            node = node->right;
        }
        else if(node->ID > ID) {
            node = node->left;
        }
    }

    return NULL;
}

// success -> return 1, else -> return 0;
int buy_stock(int ID, int amount) {
    item* target = return_stock_item_by_ID(root, ID);
    if(target == NULL) return 0;

    // P(&w); // writer lock
    P(&(target->w));
    if(target->left_stock >= amount) {
        target->left_stock -= amount;
        // V(&w); // writer lock 해제
        V(&(target->w));
        return 1;
    }
    else {
        // V(&w); // writer lock 해제
        V(&(target->w));
        // err, 재고 부족
        return 0;
    }
}

int sell_stock(int ID, int amount) {
    item* target = return_stock_item_by_ID(root, ID);
    if(target == NULL) return 0;

    // P(&w);                            // writer lock (exclusive 접근)
    P(&(target->w));
    target->left_stock += amount;       // 재고 증가
    // V(&w);                            // writer 해제
    V(&(target->w));

    return 1;
}

// 서버 종료 시, stock.txt에 내용 저장
void sigint_handler(int sig) {
    write_stocktxt();  // 서버 종료 전에 stock 저장
    sbuf_deinit(&sbuf);
    exit(0);
}

void check_client(int connfd) {
	int n;
	char buf[MAXLINE];
	rio_t rio;

    Rio_readinitb(&rio, connfd);
    while((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0){
        printf("Server received %d bytes on fd %d\n", n, connfd); //// 체크 필요
        
        if(!strncmp(buf, "show", 4)) {
            response[0] = '\0';
            // 여러 reader는 동시에 접근 가능, writer는 reader가 한 명이라도 있으면 suspend되도록
            // P(&mutex);
            // read_cnt++; // 현재 reader 수 증가
            // if (read_cnt == 1) P(&w); // 첫 reader라면 writer 막기 (writer semaphore w 획득 (writer block))
            // V(&mutex);

            show_stocks(connfd, root);
            //strcat(response, "\n"); ///

            // P(&mutex);
            // read_cnt--; // reader 수 감소
            // if (read_cnt == 0) V(&w); // 마지막 reader면 writer 허용 (writer semaphore 해제)
            // V(&mutex);

            Rio_writen(connfd, response, MAXLINE);
        }
        
        else if(!strncmp(buf, "buy", 3)) {
            char trashstr[MAXLINE];
            int inputid, inputamount;
            sscanf(buf, "%s %d %d", trashstr, &inputid, &inputamount);
            if(buy_stock(inputid, inputamount)) {
                Rio_writen(connfd, "[buy] success\n", MAXLINE); // 체크 필요
            }
            else { // txt에 없는 stock이거나, 수량 부족하거나
                Rio_writen(connfd, "Not enough left stock\n", MAXLINE); // 체크 필요
            }

        }
        else if(!strncmp(buf, "sell", 4)) {
            char trashstr[MAXLINE];
            int inputid, inputamount;
            sscanf(buf, "%s %d %d", trashstr, &inputid, &inputamount);

            if(sell_stock(inputid, inputamount)) {
                Rio_writen(connfd, "[sell] success\n", MAXLINE); // 체크 필요
            }
            else { // 해당 ID의 stock이 없는 경우, -> 출력 없이 건너뛰기
                Rio_writen(connfd, "\n", MAXLINE);
            }
        }
        else if(!strncmp(buf, "exit", 4)) {
            // write_stocktxt(); // 한 thread 종료될 때 txt 저장 // 없어도 되긴 함.//
            Rio_writen(connfd, "exit\n", MAXLINE);
            Close(connfd);
            return;
        }
    }
}

int main(int argc, char **argv) 
{
    Signal(SIGINT, sigint_handler);

    int listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;  /* Enough space for any address */  //line:netp:echoserveri:sockaddrstorage
    char client_hostname[MAXLINE], client_port[MAXLINE];
    pthread_t tid; // thread id 저장
    int i;

    if (argc != 2) {
	fprintf(stderr, "usage: %s <port>\n", argv[0]);
	exit(0);
    }

    // semaphore 초기화
    sem_init(&mutex, 0, 1); // reader lock 
    sem_init(&w, 0, 1); // writer-exclusive lock

    // stock.txt 내용 읽기
    read_stocktxt();

    listenfd = Open_listenfd(argv[1]);
    sbuf_init(&sbuf, SBUFSIZE);
    for (i = 0; i < NTHREADS; i++) {// worker threads 생성 
        Pthread_create(&tid, NULL, thread, &sbuf);
    }

    while (1) {
        clientlen = sizeof(struct sockaddr_storage); 
        connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
        // connfdp = Malloc(sizeof(int)); // 동적 할당 -> 각 thread마다 private address 가지도록 준비
        // *connfdp = Accept(listenfd, (SA *)&clientaddr, &clientlen); // 접속 수락, socket descripter 저장
        sbuf_insert(&sbuf, connfd);
        Getnameinfo((SA *) &clientaddr, clientlen, client_hostname, MAXLINE, client_port, MAXLINE, 0);
        printf("Connected to (%s, %s)\n", client_hostname, client_port);
        // Pthread_create(&tid, NULL, thread, connfdp);
        // sbuf_insert(&sbuf, *connfdp);/
    }
    exit(0);
}
/* $end echoserverimain */
