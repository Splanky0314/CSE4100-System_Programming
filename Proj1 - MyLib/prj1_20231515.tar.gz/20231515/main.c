#include "list.h"
#include "hash.h"
#include "bitmap.h"
#include <string.h>
#include <stdio.h>
#define MAX_NAME_LENGTH 128

struct list_data {
    char name[32];
    struct list list;
};

struct hash_data {
    char name[32];
    struct hash hash;
};

struct bitmap_data {
    char name[32];
    struct bitmap bitmap;
};

struct list_data lists[11];
int lists_len = 0;

struct hash_data hashs[11];
int hashs_len = 0;

struct bitmap_data bitmaps[11];
int bitmaps_len = 0;

/* LIST */
void create_list(const char *name) {
    strcpy(lists[lists_len].name, name);
    list_init(&lists[lists_len].list);
    lists_len++;
}

struct list *get_list_by_name(const char *name) {
    for(int i=0; i<lists_len; i++) {
        if(!strcmp(name, lists[i].name)) {
            return &lists[i].list;
        }
    } return NULL;    
}

void list_dumpdata(const char* name) {
    struct list* target = get_list_by_name(name);
    if(target == NULL) return;
    if(list_size(target) < 1) return;
    struct list_elem *tmp = list_begin(target);
    while(tmp != list_end(target)) {
        struct list_item *temp = list_entry(tmp, struct list_item, elem); // 여기서 elem이 뭐여?
        printf("%d ", temp->data);
        tmp = list_next(tmp);
    }
    printf("\n");
}

/* HASH */

void create_hash(const char *name) {
    strcpy(hashs[hashs_len].name, name);
    hash_init(&hashs[hashs_len].hash, hash_func, hash_less, NULL);
    hashs_len++;
}

struct hash *get_hash_by_name(const char *name) {
    for(int i=0; i<hashs_len; i++) {
        if(!strcmp(hashs[i].name, name)) {
            return &hashs[i].hash;
        } 
    } return NULL;
}

void hash_dumpdata(const char* name) {
    struct hash* target = get_hash_by_name(name);
    if(target == NULL) return;
    if(hash_size(target) < 1) return;
    struct hash_iterator it;
    hash_first(&it, target);

    while(hash_next(&it)) {
        printf("%d ", hash_entry(hash_cur(&it), struct hash_item, elem)->value);
    } printf("\n");
    
}

/* BITMAP */

void create_bitmap(const char* name, int bit_cnt) {
    strcpy(bitmaps[bitmaps_len].name, name);
    bitmaps[bitmaps_len].bitmap = *bitmap_create(bit_cnt);
    bitmaps_len++;
}

struct bitmap *get_bitmap_by_name(const char *name) {
    for(int i=0; i<bitmaps_len; i++) {
        if(!strcmp(bitmaps[i].name, name)) {
            return &bitmaps[i].bitmap;
        }
    } return NULL;
}

void bitmap_dumpdata(const char *name) {
    struct bitmap *target = get_bitmap_by_name(name);
    if(target == NULL) return;
    if(bitmap_size(target) < 1) return;
    
    for(size_t i=0; i<target->bit_cnt; i++) {
        printf("%d", bitmap_test(target, i)); 
    } printf("\n");
}

int main() {
    char line[MAX_NAME_LENGTH];
    int intdata, idxdata;
    scanf("%s", line);

    while(strcmp(line, "quit")) {
        if(!strcmp(line, "create")) {
            scanf("%s", line);
            if(!strcmp(line, "list")) {
                scanf("%s", line);
                create_list(line);
            } else if(!strcmp(line, "hashtable")) {
                scanf("%s", line);
                create_hash(line);
            } else if(!strcmp(line, "bitmap")) {
                scanf("%s", line);
                scanf("%d", &intdata);
                create_bitmap(line, intdata);
            }
        }
        else if(!strcmp(line, "delete")) {
            struct list* listtarget = get_list_by_name(line);
            if(listtarget != NULL) {
                while(!list_empty(listtarget)) {
                    struct list_elem *elem = list_pop_front(listtarget);
                    struct list_item *item = list_entry(elem, struct list_item, elem);
                    free(item);
                }
                continue;
            }
            struct hash* hashtarget = get_hash_by_name(line);
            if(hashtarget != NULL) {
                hash_destroy(hashtarget, hash_clear_action_func);
                continue; 
            }
            struct bitmap* bitmaptarget = get_bitmap_by_name(line);
            if(bitmaptarget != NULL) {
                bitmap_destroy(bitmaptarget);
                continue;
            }
        }
        else if(!strcmp(line, "dumpdata")) {
            scanf("%s", line);
            list_dumpdata(line);
            hash_dumpdata(line);
            bitmap_dumpdata(line);
        }
        // list commands
        else if(!strcmp(line, "list_insert")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            scanf("%d %d", &idxdata, &intdata);
            struct list_item *newitem = malloc(sizeof(struct list_item));
            newitem->data = intdata;

            struct list_elem *ptr = list_begin(target);
            while(idxdata > 0 && ptr != list_end(target)) {
                idxdata--;
                ptr = list_next(ptr);
            }
            list_insert(ptr, &newitem->elem);
        }
        else if(!strcmp(line, "list_splice")) {
            int insertidx, idx1, idx2;
            scanf("%s", line);
            struct list* dst = get_list_by_name(line);
            scanf("%d", &insertidx);
            scanf("%s", line);
            struct list* src = get_list_by_name(line);
            scanf("%d %d", &idx1, &idx2);
            struct list_elem *dstptr = list_begin(dst);
            while(insertidx > 0 && dstptr != list_end(dst)) {
                insertidx--;
                dstptr = list_next(dstptr);
            }
            struct list_elem *srcptr = list_begin(src);
            while(idx1 > 0 && srcptr != list_end(src)) {
                idx1--;
                srcptr = list_next(srcptr);
            }
            struct list_elem *start = srcptr;
            while(idx2 > 1 && srcptr != list_end(src)) {
                idx2--;
                srcptr = list_next(srcptr);
            }
            struct list_elem *end = srcptr;
            list_splice(dstptr, start, end);
        }
        else if(!strcmp(line, "list_push_front")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            scanf("%d", &intdata);
            struct list_item *newitem = malloc(sizeof(struct list_item));
            newitem->data = intdata;
            list_push_front(target, &newitem->elem);
        }
        else if(!strcmp(line, "list_push_back")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            scanf("%d", &intdata);
            struct list_item *newitem = malloc(sizeof(struct list_item));
            newitem->data = intdata;
            list_push_back(target, &newitem->elem);
        } 
        else if(!strcmp(line, "list_remove")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            scanf("%d", &idxdata);
            struct list_elem *ptr = list_begin(target);
            while(idxdata > 0 && ptr != list_end(target)) {
                idxdata--;
                ptr = list_next(ptr);
            }
            struct list_item *item = list_entry(ptr, struct list_item, elem);
            list_remove(ptr);
            free(item);
        }
        else if(!strcmp(line, "list_pop_front")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            struct list_elem* elem = list_pop_front(target);
            struct list_item* item = list_entry(elem, struct list_item, elem);
            free(item);
        }
        else if(!strcmp(line, "list_pop_back")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            struct list_elem* elem = list_pop_back(target);
            struct list_item* item = list_entry(elem, struct list_item, elem);
            free(item);
        }
        else if(!strcmp(line, "list_front")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            struct list_elem *tmp = list_front(target);
            struct list_item* item = list_entry(tmp, struct list_item, elem);
            printf("%d\n", item->data);
        }
        else if(!strcmp(line, "list_back")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            struct list_elem *tmp = list_back(target);
            struct list_item* item = list_entry(tmp, struct list_item, elem);
            printf("%d\n", item->data);
        }
        else if(!strcmp(line, "list_size")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            printf("%zu\n", list_size(target)); 
        }
        else if(!strcmp(line, "list_empty")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            printf("%s\n", list_empty(target) ? "true":"false");
        }
        else if(!strcmp(line, "list_reverse")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            list_reverse(target);
        }
        else if(!strcmp(line, "list_sort")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            list_sort(target, list_less, NULL);
        }
        else if(!strcmp(line, "list_insert_ordered")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            scanf("%d", &intdata);
            struct list_item *newitem = malloc(sizeof(struct list_item));
            newitem->data = intdata;
            list_insert_ordered(target, &newitem->elem, list_less, NULL);
        }
        else if(!strcmp(line, "list_unique")) { // 
            char dupli[MAX_NAME_LENGTH]; 
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            scanf("%s", dupli);
            struct list* duplicate = get_list_by_name(dupli);

            if(duplicate == NULL) { // param이 1개인 경우,
                list_unique(target, NULL, list_less, NULL);
                strcpy(line, dupli); // 다음 명령어 받도록
                continue;
            }
            list_sort(target, list_less, NULL);
            list_unique(target, duplicate, list_less, NULL);
        }
        else if(!strcmp(line, "list_max")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            struct list_elem *maxelem = list_max(target, list_less, NULL);
            struct list_item *maxitem = list_entry(maxelem, struct list_item, elem);
            if(maxelem == list_end(target)) {
                printf("EMPTY LIST\n"); // 예외처리
            } else printf("%d\n", maxitem->data);
        }
        else if(!strcmp(line, "list_min")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            struct list_elem *minelem = list_min(target, list_less, NULL);
            struct list_item *minitem = list_entry(minelem, struct list_item, elem);
            if(minelem == list_end(target)) {
                printf("EMPTY LIST\n"); // 예외처리
            } else printf("%d\n", minitem->data);
        }
        else if(!strcmp(line, "list_swap")) {
            int idx1, idx2;
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            scanf("%d %d", &idx1, &idx2);
            struct list_elem *ptr = list_begin(target);
            while(idx1 > 0 && ptr != list_end(target)) {
                idx1--;
                ptr = list_next(ptr);
            }
            struct list_elem *idx1ptr = ptr;
            ptr = list_begin(target);
            while(idx2 > 0 && ptr != list_end(target)) {
                idx2--;
                ptr = list_next(ptr);
            }

            list_swap(idx1ptr, ptr);
        }
        else if(!strcmp(line, "list_shuffle")) {
            scanf("%s", line);
            struct list* target = get_list_by_name(line);
            list_shuffle(target);
        }

        
        else if(!strcmp(line, "hash_clear")) {
            scanf("%s", line);
            struct hash* target = get_hash_by_name(line);
            hash_clear(target, hash_clear_action_func);
        }
        else if(!strcmp(line, "hash_insert")) {
            scanf("%s", line);
            struct hash* target = get_hash_by_name(line);
            scanf("%d", &intdata);
            struct hash_item* newitem = malloc(sizeof(struct hash_item));
            newitem->value = intdata;
            hash_insert(target, &newitem->elem);
        }
        else if(!strcmp(line, "hash_replace")) {
            scanf("%s", line);
            struct hash* target = get_hash_by_name(line);
            scanf("%d", &intdata);
            struct hash_item* newitem = malloc(sizeof(struct hash_item));
            newitem->value = intdata;
            hash_replace(target, &newitem->elem);
        }
        else if(!strcmp(line, "hash_find")) {
            scanf("%s", line);
            struct hash* target = get_hash_by_name(line);
            scanf("%d", &intdata);
            struct hash_item tmp;
            tmp.value = intdata;
            struct hash_elem* result = hash_find(target, &tmp.elem);
            if(result != NULL) {
                printf("%d\n", hash_entry(result, struct hash_item, elem)->value);
            }
        }
        else if(!strcmp(line, "hash_delete")) {
            scanf("%s", line);
            struct hash* target = get_hash_by_name(line);
            scanf("%d", &intdata);
            struct hash_item tmp;
            tmp.value = intdata;
            struct hash_elem *result = hash_delete(target, &tmp.elem);
        }
        else if(!strcmp(line, "hash_apply")) {
            scanf("%s", line);
            struct hash* target = get_hash_by_name(line);
            scanf("%s", line);
            if(!strcmp(line, "square")) {
                hash_apply(target, hash_apply_square_action_func);
            }
            else if(!strcmp(line, "triple")) {
                hash_apply(target, hash_apply_triple_action_func);
            }
        }
        else if(!strcmp(line, "hash_size")) {
            scanf("%s", line);
            struct hash* target = get_hash_by_name(line);
            printf("%zu\n", hash_size(target));
        }
        else if(!strcmp(line, "hash_empty")) {
            scanf("%s", line);
            struct hash* target = get_hash_by_name(line);
            printf("%s\n", hash_empty(target) ? "true" : "false");
        }

        // bitmap
        else if(!strcmp(line, "bitmap_size")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            printf("%zu\n", bitmap_size(target));
        }
        else if(!strcmp(line, "bitmap_set")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d", &intdata);
            scanf("%s", line);
            bitmap_set(target, intdata, strcmp(line, "true") ? 0:1);
        }
        else if(!strcmp(line, "bitmap_mark")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d", &intdata);
            bitmap_mark(target, intdata);
        }
        else if(!strcmp(line, "bitmap_reset")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d", &intdata);
            bitmap_reset(target, intdata);
        }
        else if(!strcmp(line, "bitmap_flip")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d", &intdata);
            bitmap_flip(target, intdata);
        }
        else if(!strcmp(line, "bitmap_test")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d", &intdata);
            printf("%s\n", bitmap_test(target, intdata)?"true":"false");
        }
        else if(!strcmp(line, "bitmap_set_all")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%s", line);
            bitmap_set_all(target, strcmp(line, "true") ? 0:1);
        }
        else if(!strcmp(line, "bitmap_set_multiple")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d %d", &intdata, &idxdata);
            scanf("%s", line);

            bitmap_set_multiple(target, intdata, idxdata, strcmp(line, "true") ? 0:1);
        }
        else if(!strcmp(line, "bitmap_count")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d %d", &intdata, &idxdata);
            scanf("%s", line);
            printf("%zu\n", bitmap_count(target, intdata, idxdata, strcmp(line, "true") ? 0:1));
        }
        else if(!strcmp(line, "bitmap_contains")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d %d", &intdata, &idxdata);
            scanf("%s", line);
            printf("%s\n", bitmap_contains(target, intdata, idxdata, strcmp(line, "true") ? 0:1)?"true":"false");
        }
        else if(!strcmp(line, "bitmap_any")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d %d", &intdata, &idxdata);
            printf("%s\n", bitmap_any(target, intdata, idxdata) ? "true":"false");
        }
        else if(!strcmp(line, "bitmap_none")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d %d", &intdata, &idxdata);
            printf("%s\n", bitmap_none(target, intdata, idxdata)?"true":"false");
        }
        else if(!strcmp(line, "bitmap_all")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d %d", &intdata, &idxdata);
            printf("%s\n", bitmap_all(target, intdata, idxdata)?"true":"false");
        }
        else if(!strcmp(line, "bitmap_scan")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d %d", &intdata, &idxdata);
            scanf("%s", line);
            printf("%zu\n", bitmap_scan(target, intdata, idxdata, strcmp(line, "true") ? 0:1));
        }
        else if(!strcmp(line, "bitmap_scan_and_flip")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d %d", &intdata, &idxdata);
            scanf("%s", line);
            printf("%zu\n", bitmap_scan_and_flip(target, intdata, idxdata, strcmp(line, "true") ? 0:1));
        }
        else if(!strcmp(line, "bitmap_file_size")) { // testfile에는 없는 명령어
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            bitmap_file_size(target);
        }
        else if(!strcmp(line, "bitmap_dump")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            bitmap_dump(target);
        }
        else if(!strcmp(line, "bitmap_expand")) {
            scanf("%s", line);
            struct bitmap* target = get_bitmap_by_name(line);
            scanf("%d", &intdata);
            bitmap_expand(target, intdata);
        }

        scanf("%s", line);
    }
    return 0;
}