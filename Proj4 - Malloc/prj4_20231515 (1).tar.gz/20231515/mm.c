/*
 * mm-naive.c - The fastest, least memory-efficient malloc package.
 * 
 * This version avoids using global variables for heap management.
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>

#include "mm.h"
#include "memlib.h"

/*********************************************************
 * NOTE TO STUDENTS: Before you do anything else, please
 * provide your information in the following struct.
 ********************************************************/
team_t team = {
    /* Your student ID */
    "20231515",
    /* Your full name*/
    "Daeun Kim",
    /* Your email address */
    "splanky03@sogang.ac.kr",
};

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8

/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(size) (((size) + (ALIGNMENT-1)) & ~0x7) // alignment 8byte로 맞춰 줌


#define SIZE_T_SIZE (ALIGN(sizeof(size_t)))

/* 기본 메크로 정의(교재에 명시) */

#define WSIZE 4 /*word & header/footer size (bytes)*/
#define DSIZE 8 /*Double word size (bytes)*/
#define CHUNKSIZE (1<<12) /*Extend heap by this amount (bytes)*/

#define MAX(x,y) ((x) > (y) ? (x) : (y))

/*Pack a size and allocated bit into a word*/
#define PACK(size, alloc) ((size) | (alloc)) // size, free/alloc 여부 묶어

/*Read and write a word at address p*/
#define GET(p) (*(unsigned int *)(p)) // p 위치에서 워드 읽기
#define PUT(p, val) (*(unsigned int *)(p) = (val)) // p 위치에서 워드 쓰기

/*Read the size and allocated fields from address p*/
#define GET_SIZE(p) (GET(p) & ~0x7) // head/footer 값에서 size값 추출
#define GET_ALLOC(p) (GET(p) & 0x1) // head/footer 값에서 free/alloc 여부 추출

/*Given block ptr bp, compute address of its header and footer*/
#define HDRP(bp) ((char*)(bp) - WSIZE) // bp로부터 header 주소 계산
#define FTRP(bp) ((char*)(bp) + GET_SIZE(HDRP(bp)) - DSIZE) // bp로부터 footer 주소 계산

/*Given block ptr bp, compute address of next and previous blocks*/
#define NEXT_BLKP(bp) ((char*)(bp) + GET_SIZE((char*)(bp) -WSIZE)) // 다음 블록의 payload 주소 계산
#define PREV_BLKP(bp) ((char *)(bp) - GET_SIZE((char*)(bp) - DSIZE)) // 이전 블록의 payload 주소 계산

////////////////////////////////////////////////////////////////////

#define PRED_P(bp) (*(char **)(bp))                      // 이전 블록 포인터
#define SUCC_P(bp) (*(char **)((char *)(bp) + WSIZE))    // 다음 블록 포인터

//////////////////////////////////////////////////////////////////////

static void insert_free_block(void *bp);
static void remove_free_block(void *bp);
static void *extend_heap(size_t words);
static void *coalesce(void *bp);
static void *find_fit(size_t asize);
static void place(void *bp, size_t asize);

///////////////////////////////////////////////////////////////////////


// heap의 첫 번째 block 가리킴
char *heap_listp;
// static char *free_list_head = 0; // free list의 시작 payload 위치 저장

void insert_free_block(void *bp) {
    SUCC_P(bp) = SUCC_P(heap_listp);
    PRED_P(bp) = heap_listp;
    PRED_P(SUCC_P(heap_listp)) = bp;
    SUCC_P(heap_listp) = bp;
}

void remove_free_block(void *bp) {
    SUCC_P(PRED_P(bp)) = SUCC_P(bp);
    PRED_P(SUCC_P(bp)) = PRED_P(bp);
}


static void *extend_heap(size_t words) {
    char *bp;
    size_t size;

    // double-word align이니까, 요청된 크기를 짝수로 맞추고 byte 단위로 변환
    size = (words % 2) ? (words + 1) * WSIZE : words * WSIZE;

    // 힙 확장 요청
    if ((long)(bp = mem_sbrk(size)) == -1) return NULL;

    // 새 free 블록의 header, footer, 새 epilogue header 설정
    PUT(HDRP(bp), PACK(size, 0)); // header
    PUT(FTRP(bp), PACK(size, 0)); // footer
    PUT(HDRP(NEXT_BLKP(bp)), PACK(0, 1)); // new epilogue header

    // coalescing 후 포인터 반환
    return coalesce(bp);
}

static void *coalesce(void *bp) {
    size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp)));
    size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
    size_t size = GET_SIZE(HDRP(bp)); 

    // next block이 free상태인 경우,
    if (prev_alloc && !next_alloc) {
        remove_free_block(NEXT_BLKP(bp)); // next block 제거
        size += GET_SIZE(HDRP(NEXT_BLKP(bp))); // 크기값 합치고
        PUT(HDRP(bp), PACK(size, 0)); // 현재 block header에 size, flag 저장
        PUT(FTRP(bp), PACK(size, 0)); // 현재 block footer에 동일 내용 저장
    }

    // prev block이 free 상태인 경우,
    else if (!prev_alloc && next_alloc) {
        remove_free_block(PREV_BLKP(bp)); // prev block 제거
        size += GET_SIZE(HDRP(PREV_BLKP(bp))); // 크기값 합치고
        bp = PREV_BLKP(bp);
        PUT(HDRP(bp), PACK(size, 0)); // prev block의 header에 정보 기록
        PUT(FTRP(bp), PACK(size, 0)); // 현재 block footer에 정보 기록
    }

    // prev, next block 다 free 상태인 경우,
    else if(!prev_alloc && !next_alloc){
        remove_free_block(PREV_BLKP(bp)); // prev block 제거
        remove_free_block(NEXT_BLKP(bp)); // next block 제거
        size += GET_SIZE(HDRP(PREV_BLKP(bp))) + GET_SIZE(FTRP(NEXT_BLKP(bp))); // 크기값 합치고
        bp = PREV_BLKP(bp); // bp를 prev block으로 이동
        PUT(HDRP(bp), PACK(size, 0)); // prev block header에 정보 기록
        PUT(FTRP(bp), PACK(size, 0)); // next block footer에 정보 기록
    }

    insert_free_block(bp); // 병합 결과 블록을 free list에 다시 추가
    return bp;
}

static void *find_fit(size_t asize) {
    void *bp;
    
    for(bp = SUCC_P(heap_listp); GET_ALLOC(HDRP(bp)) == 0; bp = SUCC_P(bp)){
        if(asize <= GET_SIZE(HDRP(bp))){
            return bp;
        }
    }

    return NULL; 
}


// 할당 가능한 블록을 실제로 할당하기
static void place(void *bp, size_t asize) {
    size_t cur_size = GET_SIZE(HDRP(bp)); // current block 전체 크기

    remove_free_block(bp); // free list에서 제거

    // 충분한 공간 있다면, block 분할하기
    if((cur_size - asize) >= (2*DSIZE)){
        // current block 할당, footer/header
        PUT(HDRP(bp), PACK(asize, 1)); 
        PUT(FTRP(bp), PACK(asize, 1)); 

        PUT(HDRP(NEXT_BLKP(bp)), PACK(cur_size-asize, 0)); 
        PUT(FTRP(NEXT_BLKP(bp)), PACK(cur_size-asize,0));

        // 분할된 free block을 free list에 insert
        insert_free_block(NEXT_BLKP(bp)); 
    }
    // 충분한 공간 없다면,
    else { 
        PUT(HDRP(bp), PACK(cur_size, 1));
        PUT(FTRP(bp), PACK(cur_size, 1));
    }
}



/* 
 * mm_init - initialize the malloc package.
 */
int mm_init(void)
{
    // empty heap 세팅
    // 6 word = padding + prologue header + pred + succ + footer + epilogue
    if ((heap_listp = mem_sbrk(6 * WSIZE)) == (void *)-1)
        return -1;

    PUT(heap_listp, 0);                                      // 정렬을 위한 padding
    PUT(heap_listp + (1 * WSIZE), PACK(2 * DSIZE, 1));       // prologue header (size=16, alloc=1)
    PUT(heap_listp + (2 * WSIZE), heap_listp + (3 * WSIZE));
    PUT(heap_listp + (3 * WSIZE), heap_listp + (2 * WSIZE));
    PUT(heap_listp + (4 * WSIZE), PACK(2 * DSIZE, 1));       // prologue footer
    PUT(heap_listp + (5 * WSIZE), PACK(0, 1));               // epilogue header

    // heap_listp가 paylod를 가리키도록
    heap_listp += (2 * WSIZE);

    // 아직 block 없으니 NULL로
    // free_list_head = NULL;

    if (extend_heap(CHUNKSIZE / WSIZE) == NULL)
        return -1;
    
    return 0;
}

/* 
 * mm_malloc - Allocate a block by incrementing the brk pointer.
 *     Always allocate a block whose size is a multiple of the alignment.
 */
void *mm_malloc(size_t size)
{
    size_t asize;        // 정렬된 블록 크기
    size_t extendsize;   // 힙 확장 시 사용될 크기
    char *bp;

    // 요청된 크기가 size = 0이면
    if (size == 0) return NULL;

    // 요청 크기 + header&footer 
    if (size <= DSIZE)
        asize = 2 * DSIZE;  // 최소 블록 크기 (header + footer + pred/succ)
    else
        asize = ALIGN(size + DSIZE); // payload + header/footer

    // free list에서 적절한 블록 탐색
    if ((bp = find_fit(asize)) != NULL) {
        place(bp, asize);  // 블록 할당 및 분할 처리
        return bp;
    }

    // 적절한 블록이 없다면, 힙 확장 후 재시도
    extendsize = MAX(asize, CHUNKSIZE);  // 확장 크기 선택
    if ((bp = extend_heap(extendsize / WSIZE)) == NULL)
        return NULL;

    place(bp, asize);
    return bp;
}

/*
 * mm_free - Freeing a block does nothing.
 */
void mm_free(void *ptr)
{
    if (ptr == NULL) return;

    size_t size = GET_SIZE(HDRP(ptr)); // current block size

    // header&footer free 상태로 세팅
    PUT(HDRP(ptr), PACK(size,0));
    PUT(FTRP(ptr), PACK(size,0));

    coalesce(ptr); // 병합 시도
}

/*
 * mm_realloc - Implemented simply in terms of mm_malloc and mm_free
 */
void *mm_realloc(void *ptr, size_t size)
{
    // 기존 block 없으면
    if (ptr == NULL) return mm_malloc(size);
    // 0 할당이면,
    if (size == 0) {
        mm_free(ptr);
        return NULL;
    }

    void *oldptr = ptr;  
    void *newptr;        
    
    size_t oldSize = GET_SIZE(HDRP(oldptr)); // 기존 block 전체 크기
    size_t newSize = ALIGN(size + SIZE_T_SIZE); // 요청된 size + header&footer 포함 크기
    size_t nextSize = GET_SIZE(HDRP(NEXT_BLKP(oldptr))) + oldSize;

    // size가 기존 block보다 작거나 같다면,
    if(newSize <= oldSize) return oldptr; 
    // 합칠 수 있고 다음 block이 free 상태
    else if (newSize <= nextSize && !GET_ALLOC(HDRP(NEXT_BLKP(oldptr)))){
        remove_free_block(NEXT_BLKP(oldptr));
        PUT(FTRP(oldptr), PACK(0,0));
        PUT(HDRP(oldptr), PACK(nextSize, 1));
        PUT(FTRP(oldptr), PACK(nextSize, 1));
        return oldptr;
    }

    newptr = mm_malloc(newSize); // new block 할당
    if(newptr == NULL) return NULL;
    
    place(newptr, newSize);
    memcpy(newptr, oldptr, newSize); // payload만 복사
    mm_free(oldptr);
    return newptr;
}
