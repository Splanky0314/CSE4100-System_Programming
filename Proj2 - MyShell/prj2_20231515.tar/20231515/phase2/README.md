# CSE4100 - Project 2

## Phase 2


### 프로그램 실행 방법
```
make

./myshell
```

### 프로그램 실행 및 조작 방법

cd : 명시된 디렉터리로 이동

ls : 디렉토리에 소속된 폴더 및 파일 출력

mkdir : 디렉토리 생성

rmdir : 디렉토리 삭제

touch : 파일 생성

cat : 문자, 파일 내용 출력

echo : 문자, 파일 내용 출력

exit : myshell 종료

quit : myshell 종료

<Phase 2 추가>

| : 파이프, 앞선 명령의 결과 출력을 다른 명령의 입력으로 사용할 수 있도록 하는 명령