/* $begin shellmain */
#include "shellex.h"

job_t jobs[MAXARGS]; 
int next_jid = 1; // 다음 job이 가지게 될 id

void addjob(pid_t pid, char state, const char *cmdline) {
    for(int i=0; i<MAXJOBS; i++) {
        if(jobs[i].jid == 0) { // 빈 배열요소라면
            jobs[i].jid = next_jid++;
            jobs[i].pid = pid;
            jobs[i].state = state;
            strcpy(jobs[i].cmdline, cmdline);
            return;
        }
    }
}

void deletejob(pid_t pid) {
    for(int i=0; i<MAXJOBS; i++) {
        if(jobs[i].pid == pid) {
            jobs[i].pid = 0;
            jobs[i].jid = 0;
            jobs[i].state = '\0';
            jobs[i].cmdline[0] = '\0';
            return;
        }
    }
}

// 성공하면 return 1
int listjobs() { 
    for(int i=0; i<MAXJOBS; i++) {
        if(jobs[i].pid != 0) {
            if(jobs[i].state == 'b') {
                printf("[%d] Running\t%s\n", jobs[i].jid, jobs[i].cmdline);
            }
            else if(jobs[i].state == 'f') { // 필요없긴함
                printf("[%d] Running\t%s\n", jobs[i].jid, jobs[i].cmdline);
            }
            else if(jobs[i].state == 's') {
                printf("[%d] Stopped\t%s\n", jobs[i].jid, jobs[i].cmdline);
            }
        }
    }
    return 1;
}

void handler_chld(int signal) {
    int status;
    pid_t pid;

    // WNOHANG: 자식이 아직 안 끝났으면 기다리지 않음
    // WUNTRACED: 중지된 자식도 감지
    while (1) {
        if((pid = waitpid(-1, &status, WNOHANG | WUNTRACED)) > 0) {
            // 자식이 정상 종료되었거나 시그널로 종료됨 
            if (WIFEXITED(status) || WIFSIGNALED(status)) {
                deletejob(pid);
            } 
            // Ctrl+Z로 멈춘 경우 
            else if (WIFSTOPPED(status)) {
                // jobs[]에서 state 변경
                for (int i = 0; i < MAXJOBS; i++) {
                    if (jobs[i].pid == pid) {
                        jobs[i].state = 's';
                        break;
                    }
                }
            }
        }
        else break;
        
    }
}

void handler_int(int signal) {
    int old_errno = errno;

    for (int i = 0; i < MAXJOBS; i++) {
        if (jobs[i].pid != 0 && jobs[i].state == 'f') {
            // 프로세스 그룹 전체에 SIGINT 전송
            pid_t pgid = getpgid(jobs[i].pid); // 프로세스 그룹 ID를 가져옴
            if (pgid > 0) {
                Kill(-pgid, SIGINT); // 해당 그룹 전체에 SIGTSTP 전송
            } 
            break; // 하나만 처리 (포그라운드 job은 하나뿐)
        }
    }

    errno = old_errno;
}

void handler_stp(int signal) {
    int old_errno = errno;

    for (int i = 0; i < MAXJOBS; i++) {
        if (jobs[i].pid != 0 && jobs[i].state == 'f') {
            // 포그라운드 프로세스 그룹 전체를 정지시킴
            jobs[i].state = 's';
            pid_t pgid = getpgid(jobs[i].pid); // 프로세스 그룹 ID를 가져옴
            if (pgid > 0) {
                Kill(-pgid, SIGTSTP); // 해당 그룹 전체에 SIGTSTP 전송
            } 
            break;
        }
    }

    errno = old_errno;
}

/* phase 3 */
int change_job_state(char **argv, char newstate) {
    job_t *targetjob = NULL;

    if(argv[1] != NULL) {
        if(argv[1][0] == '%') { // jid 경우
            int jid = atoi(&argv[1][1]);
            for(int i=0; i<MAXJOBS; i++) {
                if(jobs[i].jid == jid) {
                    targetjob = &jobs[i];
                }
            }
        }
        else if(isdigit(argv[1][0])) { // pid 경우
            int pid = atoi(&argv[1][0]);
            for(int i=0; i<MAXJOBS; i++) {
                if(jobs[i].pid == pid) {
                    targetjob = &jobs[i];
                }
            }
        }
    }

    if (!targetjob) {
        fprintf(stderr, "change_job_state(): job not found\n");
        return 0;
    }

    targetjob->state = newstate;
    pid_t pgid = getpgid(targetjob->pid); // 프로세스 그룹 ID를 가져옴
    if (pgid > 0) {
        Kill(-pgid, SIGCONT); // 해당 그룹 전체에 SIGTSTP 전송
    }

    if(newstate == 'f') {
        int status;
        waitpid(targetjob->pid, &status, WUNTRACED); 

        // 중지된 경우면 상태를 다시 바꿔줘야 함
        if (WIFSTOPPED(status)) {
            targetjob->state = 's';
        } else {
            deletejob(targetjob->pid); // 종료된 경우
        }

    }

    return 1;    
}

int main() 
{
    Signal(SIGCHLD, handler_chld);
    Signal(SIGINT, handler_int);
    Signal(SIGTSTP, handler_stp);

    for(int i=0; i<MAXJOBS; i++) {
        jobs[i].cmdline[0] = '\0';
        jobs[i].jid = 0;
        jobs[i].pid = 0;
        jobs[i].state = '\0';
    }

    char cmdline[MAXLINE]; /* Command line */

    while (1) {
        /* Read */
        printf("CSE4100-SP-P2> ");                   
        fgets(cmdline, MAXLINE, stdin); 
        if (feof(stdin))
            exit(0);

        /* Evaluate */
        eval(cmdline);
    } 
}
/* $end shellmain */
  
/* $begin eval */
/* eval - Evaluate a command line */
void eval(char *cmdline) 
{
    char *argv[MAXARGS]; /* Argument list execve() */
    char buf[MAXLINE];   /* Holds modified command line */
    int bg;              /* Should the job run in bg or fg? */
    pid_t pid;           /* Process id */
    sigset_t mask;

    strcpy(buf, cmdline);
    bg = parseline(buf, argv); 
    if (argv[0] == NULL)  
	return;   /* Ignore empty lines */
    
    char **commands[MAXARGS];
    int commands_num = parse_pipe(argv, commands);
    if (!builtin_command(argv)) { //quit -> exit(0), & -> ignore, other -> run
        Sigemptyset(&mask);
        Sigaddset(&mask, SIGCHLD);
        Sigprocmask(SIG_BLOCK, &mask, NULL);

        if((pid = Fork()) == 0) { // 자식 프로세스라면
            if(bg) { // background 실행인 경우
                setpgid(0, 0);
            }

            if(commands_num > 1) {
                execute_pipe(commands, commands_num);
                exit(0); // 자식 종료
            }
            else {
                fflush(stdout);
                char path[128] = "/bin/";
                strcat(path, argv[0]);
                if(execve(path, argv, environ) < 0) {
                    printf("%s: Command not found.\n", argv[0]);
                    exit(0);
                }
 
            }
        }
        else {
            if (!bg) {
                addjob(pid, 'f', cmdline);  // job 생성
            } else {
                addjob(pid, 'b', cmdline);  // job 생성
            }
            /* Parent waits for foreground job to terminate */
            Sigprocmask(SIG_UNBLOCK, &mask, NULL);
            
            if (!bg){ // 포그라운드 작업
                Sigprocmask(SIG_UNBLOCK, &mask, NULL);
                int status;
                if(waitpid(pid, &status, WUNTRACED) < 0) {
                    if(errno != ECHILD)
                        perror("waitpid");
                }

                if(WIFEXITED(status)) { // 자식이 종료된 경우
                    deletejob(pid);
                }
            }
            else { // when there is backgrount process!
                printf("%d %s", pid, cmdline); // 머지 원래 있던건데 for test
                printf("[%d] %d %s", next_jid - 1, pid, cmdline); ///
            }
        }
    }
    return;
}

/* Phase2: */
void execute_pipe(char *** commands, int commands_num) {
    pid_t pids[commands_num];
    pid_t pgid = 0;
    sigset_t mask;
    int fds[commands_num-1][2];
    sigemptyset(&mask);
    sigaddset(&mask, SIGCHLD);
    sigprocmask(SIG_BLOCK, &mask, NULL);

    // pipe fd 생성
    for(int i=0; i<commands_num-1; i++) {
        if(pipe(fds[i]) < 0) {
            perror("pipe");
            exit(1);
        }
    }

    // 각 command에 대해
    for(int i=0; i<commands_num; i++) {
        if((pids[i] = Fork()) == 0) { // child process 체크 필요
            Sigprocmask(SIG_UNBLOCK, &mask, NULL);
            if (pgid == 0) pgid = getpid(); // 첫 자식이면 자기 자신을 그룹 리더로 설정
            if (setpgid(0, pgid) < 0) {
                perror("setpgid");
                exit(1);
            }

            // stdin 연결
            if(i != 0) {
                dup2(fds[i-1][0], STDIN_FILENO);
            }
            // stdout 연결
            if(i != commands_num-1) {
                dup2(fds[i][1], STDOUT_FILENO);
            }

            for(int j=0; j<commands_num-1; j++) {
                close(fds[j][0]);
                close(fds[j][1]);
            }

            execvp(commands[i][0], commands[i]);
            fprintf(stderr, "%s: command not found\n", commands[i][0]);
            exit(1);
        }
        else { // parent process
            if(pgid == 0) pgid = pids[i];
            setpgid(pids[i], pgid);
        }
    } 
    
    for(int i=0; i<commands_num-1; i++) {
        close(fds[i][0]);
        close(fds[i][1]);
    }

    Sigprocmask(SIG_UNBLOCK, &mask, NULL);
    int status;
    for (int i = 0; i < commands_num; i++) {
        waitpid(pids[i], &status, 0);
    }
}

/* Phase2: return commands_cnt */
int parse_pipe(char** argv, char **commands[]) {
    int idx = 0;
    int command_start_idx = 0;
    int commands_cnt = 0;

    while(argv[idx]) {
        if(!strcmp(argv[idx], "|")) {
            argv[idx] = NULL;
            commands[commands_cnt] = &argv[command_start_idx];
            commands_cnt++;
            command_start_idx = idx+1;
        }
        idx++;
    }
    commands[commands_cnt] = &argv[command_start_idx];
    commands_cnt++;

    return commands_cnt;
}

/* If first arg is a builtin command, run it and return true */
int builtin_command(char **argv) 
{
    if (!strcmp(argv[0], "quit")) /* quit command */
	exit(0);  
    if (!strcmp(argv[0], "&"))    /* Ignore singleton & */
	return 1;
    /* Phase 1 구현 */
    if(!strcmp(argv[0], "cd")) {
        if(argv[1] == NULL) {
            fprintf(stderr, "cd: missing argument\n");
        }
        else {
            if(chdir(argv[1]) == -1) {
                // "cd:" + strerror(errno) 출력됨
                perror("cd");
            } 
        }
        return 1; // 예외여도 그대로 실행? 체크필요
    }
    else if(!strcmp(argv[0], "exit")) {
        exit(0);
    }
    else if(!strcmp(argv[0], "jobs")) {
        return listjobs();
    }
    // stopped 상태인 background 작업을 다시 실행
    else if(!strcmp(argv[0], "bg")) { 
        return change_job_state(argv, 'b');
    }
    else if(!strcmp(argv[0], "fg")) {
        return change_job_state(argv, 'f');
    }
    else if(!strcmp(argv[0], "kill")) {
        if (argv[1] == NULL) {
            fprintf(stderr, "kill: usage: kill [-s sigspec | -n signum | -sigspec] pid | jobspec ... or kill -l [sigspec]\n");
            return 1;
        }

        if(argv[1][0] == '%') { // jid 경우
            int jid = atoi(&argv[1][1]);
            for(int i=0; i<MAXJOBS; i++) {
                if(jobs[i].jid == jid) {
                    Kill(jobs[i].pid, SIGKILL);
                    deletejob(jobs[i].pid);
                    return 1;
                }
            }
            fprintf(stderr, "kill: no such job: %s\n", argv[1]);
        }
        else if(isdigit(argv[1][0])) { // pid 경우
            int pid = atoi(&argv[1][0]);
            for(int i=0; i<MAXJOBS; i++) {
                if(jobs[i].pid == pid) {
                    Kill(pid, SIGKILL);
                    deletejob(jobs[i].pid);
                    return 1;
                }
            }
            fprintf(stderr, "kill: no such process: %s\n", argv[1]);
        }
        else {
            fprintf(stderr, "kill: invalid argument: %s\n", argv[1]);
        }
        return 1;
    }
    
    return 0;                     /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char *buf, char **argv) 
{
    char *delim;         /* Points to first space delimiter */
    int argc;            /* Number of args */
    int bg;              /* Background job? */

    buf[strlen(buf)-1] = ' ';  /* Replace trailing '\n' with space */
    while (*buf && (*buf == ' ')) /* Ignore leading spaces */
	buf++;

    /* Build the argv list */
    argc = 0;
    while ((delim = strchr(buf, ' '))) {
	argv[argc++] = buf;
	*delim = '\0';
	buf = delim + 1;
	while (*buf && (*buf == ' ')) /* Ignore spaces */
            buf++;
    }
    argv[argc] = NULL;
    
    if (argc == 0)  /* Ignore blank line */
	return 1;

    /* Should the job run in the background? */
    if ((bg = (*argv[argc-1] == '&')) != 0)
	argv[--argc] = NULL;

    return bg;
}
/* $end parseline */


