# CSE4100 - Project 2

## Phase 3


### 프로그램 실행 방법
```
make

./myshell
```

### 프로그램 실행 및 조작 방법

cd : 명시된 디렉터리로 이동

ls : 디렉토리에 소속된 폴더 및 파일 출력

mkdir : 디렉토리 생성

rmdir : 디렉토리 삭제

touch : 파일 생성

cat : 문자, 파일 내용 출력

echo : 문자, 파일 내용 출력

exit : myshell 종료

quit : myshell 종료

<Phase 2 추가>

| : 파이프, 앞선 명령의 결과 출력을 다른 명령의 입력으로 사용할 수 있도록 하는 명령

<Phase 3 추가>

jobs : 현재 백그라운드 및 중지된 작업들을 목록으로 출력
bg : stopped 상태인 background 작업을 background에서 실행, 또는 foreground에 있는 작업을 foreground로 옮김
fg : stopped 또는 background 작업을 foreground로 옮겨서 실행
kill : 특정 작업에 SIGKILL 시그널을 보내 신호를 보내 종료
& : 명령어를 백그라운드로 실행