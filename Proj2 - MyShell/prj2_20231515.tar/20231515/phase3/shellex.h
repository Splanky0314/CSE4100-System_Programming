#ifndef SHELLEX_H
#define SHELLEX_H

#include "csapp.h"
#include <errno.h>
#define MAXARGS   128
#define MAXJOBS   128 // 체크 필요

// Phase 3: jobs
typedef struct job {
    int jid;
    pid_t pid;
    char state; // 'f'- forground / 'b' - background / 's' - stopped
    char cmdline[MAXLINE];
} job_t;

void addjob(pid_t pid, char state, const char *cmdline);
void deletejob(pid_t pid);
int listjobs();
int change_job_state(char **argv, char newstate);

void handler_chld(int signal);
void handler_int(int signal);
void handler_stp(int signal);

void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv); 
void execute_pipe(char *** commands, int commands_num); // Phase 2
int parse_pipe(char** argv, char **commands[]); // Phase 2

#endif /* SHELLEX_H */